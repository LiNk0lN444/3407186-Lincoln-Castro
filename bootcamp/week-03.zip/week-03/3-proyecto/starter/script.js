// ============================================
// CLASES DE PERSONAS (USUARIOS)
// ============================================
class Person {
  #id = crypto.randomUUID();
  #name;
  #email;

  constructor(name, email) {
    this.#name = name;
    this.#email = email;
  }

  get name() { return this.#name; }
  get info() { return `${this.#name} (${this.#email})`; }
}

class Technician extends Person {
  #specialty;
  constructor(name, email, specialty) {
    super(name, email);
    this.#specialty = specialty;
  }
  get info() { return `🔧 Técnico: ${this.name} - Esp: ${this.#specialty}`; }
}

// ============================================
// SISTEMA PRINCIPAL (WAREHOUSE)
// ============================================
class WarehouseSystem {
  #items = [];
  #users = [];

  static {
    console.log("🛠️ Sistema de Bodega de Herramientas Listo.");
  }

  // Métodos para Herramientas
  addItem(item) { this.#items.push(item); }
  getAllItems() { return [...this.#items]; }

  // Métodos para Usuarios
  addUser(user) { this.#users.push(user); }
  getUsers() { return [...this.#users]; }

  // Estadísticas
  getStats() {
    return {
      totalTools: this.#items.length,
      totalUsers: this.#users.length,
      lowStock: this.#items.filter(i => i.stock < 5).length
    };
  }
}

const system = new WarehouseSystem();

// ============================================
// LÓGICA DE NAVEGACIÓN (TABS)
// ============================================
const setupNavigation = () => {
  const tabs = document.querySelectorAll(".tab-btn");
  const panels = document.querySelectorAll(".tab-panel");

  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      const target = tab.getAttribute("data-tab");

      // Actualizar botones
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      // Mostrar panel correcto
      panels.forEach(panel => {
        panel.style.display = panel.id === target ? "block" : "none";
      });

      // Refrescar datos según la pestaña
      if (target === "users") renderUsers();
      if (target === "stats") renderStats();
    });
  });
};

// ============================================
// RENDERIZADO EN EL DOM
// ============================================
const renderItems = () => {
  const container = document.getElementById("item-list");
  if (!container) return;
  container.innerHTML = system.getAllItems()
    .map(item => `<div class="item-card">${item.getInfo()}</div>`)
    .join("");
};

const renderUsers = () => {
  const container = document.getElementById("user-list");
  if (!container) return;
  container.innerHTML = system.getUsers()
    .map(u => `<div class="member-card"><h4>${u.info}</h4></div>`)
    .join("");
};

const renderStats = () => {
  const stats = system.getStats();
  const container = document.getElementById("stats-container"); // Crea este ID en tu HTML
  if (!container) return;
  container.innerHTML = `
    <div class="stat-card"><h3>${stats.totalTools}</h3><p>Herramientas</p></div>
    <div class="stat-card"><h3>${stats.totalUsers}</h3><p>Personal</p></div>
    <div class="stat-card" style="color: var(--accent-red)"><h3>${stats.lowStock}</h3><p>Bajo Stock</p></div>
  `;
};

// ============================================
// INICIALIZACIÓN
// ============================================
const init = () => {
  // Datos de prueba
  system.addItem(new ElectricTool("Taladro", 10, 110));
  system.addUser(new Technician("Carlos Pérez", "carlos@herramientas.com", "Mecánica"));
  
  setupNavigation();
  renderItems();
};

document.addEventListener("DOMContentLoaded", init);